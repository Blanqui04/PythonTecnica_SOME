class TransformationError(Exception):
    """Excepció personalitzada per errors durant la transformació de dades."""
    pass